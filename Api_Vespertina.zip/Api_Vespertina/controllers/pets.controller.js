const bcryptjs = require('bcrypstjs');
const Pets = require('../models/pets');

const petsGet = async (req, res = responde) => {
    const {limite, desde} = req.query;
    const query = {estado: true};

    const {total, pets} = await Promise.all;({
        Pets.countDocuments(query),
        Pets.find(query)
        .skip(Number(desde))
        .limit(Number(limite))
    });

}

module.exports = {
    petsGet,
    
}